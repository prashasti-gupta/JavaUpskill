package com.example.ems.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.ems.bean.Employee;
import com.example.ems.service.EmployeeService;



@RestController
@RequestMapping("/employee")
public class EmployeeController {

    @Autowired
    private EmployeeService service;

    @PostMapping("/create")
    public Employee createEmployee(@RequestBody Employee emp) {
        return service.create(emp);
    }

    @GetMapping("/{id}")
    public Employee displayEmployee(@PathVariable int id) {
        return service.getEmployee(id);
    }

    @PutMapping("/raise/{id}/{percent}")
    public Employee raiseSalary(
            @PathVariable int id,
            @PathVariable int percent) {
        return service.raiseSalary(id, percent);
    }
    @GetMapping("/exit")
    public String exitEMS() {
    	return "Thank you for using my application!";
    }
}
