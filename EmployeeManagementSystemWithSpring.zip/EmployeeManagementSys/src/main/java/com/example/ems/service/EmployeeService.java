package com.example.ems.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.ems.bean.Employee;
import com.example.ems.repository.EmployeeRepository;


@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    public Employee create(Employee emp) {

        if (emp.getAge() < 20 || emp.getAge() > 60) {
            throw new RuntimeException("Age must be between 20 and 60");
        }

        switch (emp.getDesignation().toUpperCase()) {
            case "P":
                emp.setDesignation("Programmer");
                emp.setSalary(20000.0);
                break;
            case "M":
                emp.setDesignation("Manager");
                emp.setSalary(25000.0);
                break;
            case "T":
                emp.setDesignation("Tester");
                emp.setSalary(15000.0);
                break;
            default:
                throw new RuntimeException("Invalid Designation");
        }

        return employeeRepository.save(emp);
    }

    
    public Employee getEmployee(int id) {
        return employeeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Employee not found"));
    }

    public Employee raiseSalary(int id, int percent) {

        if (percent < 1 || percent > 10) {
            throw new RuntimeException("Percentage must be 1 to 10");
        }

        Employee emp = getEmployee(id);
        double increment = emp.getSalary() * percent / 100;
        emp.setSalary(emp.getSalary() + increment);

        return employeeRepository.save(emp);
    }
}
