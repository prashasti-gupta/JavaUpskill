package com.example.ems.service;

import java.util.Optional;
import org.springframework.stereotype.Service;
import com.example.ems.model.Employee;
import com.example.ems.repository.EmployeeRepository;

@Service
public class EmployeeService {

    private final EmployeeRepository repo;

    public EmployeeService(EmployeeRepository repo) {
        this.repo = repo;
    }

    public String create(Employee emp) {
        if (emp.getName().trim().split(" ").length - 1 > 2)
            return "Name can have max two spaces";

        if (emp.getAge() < 20 || emp.getAge() > 60)
            return "Age must be between 20 and 60";

        switch (emp.getDesignation().toLowerCase()) {
            case "programmer" -> emp.setSalary(20000);
            case "tester" -> emp.setSalary(15000);
            case "manager" -> emp.setSalary(25000);
            default -> {
                return "Invalid designation";
            }
        }
        repo.save(emp);
        return "Employee created successfully";
    }

    public Optional<Employee> findByName(String name) {
        return repo.findByName(name);
    }

    public String raiseSalary(String name, int percent) {
        if (percent < 1 || percent > 10)
            return "Invalid percentage";

        Optional<Employee> opt = repo.findByName(name);
        if (opt.isEmpty()) return "Employee does not exist!";

        Employee e = opt.get();
        e.setSalary(e.getSalary() + (e.getSalary() * percent / 100));
        repo.save(e);
        return "Salary updated";
    }
}