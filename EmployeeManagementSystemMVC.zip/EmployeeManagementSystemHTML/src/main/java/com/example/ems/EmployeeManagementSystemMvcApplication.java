package com.example.ems;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeManagementSystemMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagementSystemMvcApplication.class, args);
	}

}
