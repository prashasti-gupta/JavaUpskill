package com.example.ems.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import com.example.ems.model.Employee;
import com.example.ems.service.EmployeeService;

@Controller
public class EmployeeController {

    private final EmployeeService service;

    public EmployeeController(EmployeeService service) {
        this.service = service;
    }

    @GetMapping("/")
    public String menu() {
        return "index";
    }

    @GetMapping("/create")
    public String createForm(Model model) {
        model.addAttribute("emp", new Employee());
        return "create";
    }

    @PostMapping("/create")
    public String create(Employee emp, Model model) {
        model.addAttribute("msg", service.create(emp));
        return "result";
    }

    @GetMapping("/display")
    public String displayForm() {
        return "display";
    }

    @PostMapping("/display")
    public String display(@RequestParam String name, Model model) {
    	var empDisplay = service.findByName(name);
        
    	if(empDisplay.isPresent()) {
    		model.addAttribute("emp", empDisplay.get());
    	} else {
    		model.addAttribute("msg", "Employee does not exist!");
    	}
        return "result";
    }

    @GetMapping("/raise")
    public String raiseForm() {
        return "raise";
    }

    @PostMapping("/raise")
    public String raise(@RequestParam String name,
                        @RequestParam int percent,
                        Model model) {
        model.addAttribute("msg", service.raiseSalary(name, percent));
        return "result";
    }

    @GetMapping("/exit")
    public String exit() {
        return "exit";
    }
}