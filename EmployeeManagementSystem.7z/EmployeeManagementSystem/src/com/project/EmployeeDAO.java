package com.project;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDAO {

    private static final String URL = "jdbc:mysql://localhost:3306/employee_db";
    private static final String USER = "root";
    private static final String PASS = "Root123$";

    public EmployeeDAO() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); 
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void addEmployee(Employee emp) {
        String sql = "INSERT INTO employees (name, age, designation, salary) VALUES (?, ?, ?, ?)";

        try (Connection con = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, emp.getName());
            ps.setInt(2, emp.getAge());
            ps.setString(3, emp.getDesignation());
            ps.setDouble(4, emp.getSalary());
            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<Employee> getLast10Employees() {
        List<Employee> list = new ArrayList<>();
        String sql = "SELECT name, age, designation, salary FROM employees ORDER BY id DESC LIMIT 10";

        try (Connection con = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(new Employee(
                        rs.getString("name"),
                        rs.getInt("age"),
                        rs.getString("designation"),
                        rs.getDouble("salary")
                ));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    public boolean raiseSalary(String name, int percent) {
        String select = "SELECT salary FROM employees WHERE name=?";
        String update = "UPDATE employees SET salary=? WHERE name=?";

        try (Connection con = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement psSelect = con.prepareStatement(select)) {

            psSelect.setString(1, name);
            ResultSet rs = psSelect.executeQuery();

            if (!rs.next()) return false;

            double current = rs.getDouble("salary");
            double raised = current + (current * percent / 100.0);

            try (PreparedStatement psUpdate = con.prepareStatement(update)) {
                psUpdate.setDouble(1, raised);
                psUpdate.setString(2, name);
                psUpdate.executeUpdate();
            }

            return true;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }
}