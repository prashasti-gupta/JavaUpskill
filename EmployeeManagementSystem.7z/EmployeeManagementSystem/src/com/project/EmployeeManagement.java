package com.project;

import java.util.*;

public class EmployeeManagement {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        EmployeeDAO dao = new EmployeeDAO();

        while (true) {
            System.out.println("\n===== MENU =====");
            System.out.println("1. Create");
            System.out.println("2. Display");
            System.out.println("3. Raise Salary");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");

            int ch = sc.nextInt();
            sc.nextLine(); 

            switch (ch) {

                case 1:
                    System.out.print("Enter Name (max 2 whitespaces allowed): ");
                    String name = sc.nextLine();
                    if (name.chars().filter(c -> c == ' ').count() > 2) {
                        System.out.println("Error: Too many spaces! Only two allowed");
                        break;
                    }

                    System.out.print("Enter Age (20-60): ");
                    int age = sc.nextInt();
                    sc.nextLine();
                    if (age < 20 || age > 60) {
                        System.out.println("Invalid age");
                        break;
                    }

                    System.out.print("Enter Designation (programmer/manager/tester): ");
                    String des = sc.nextLine().toLowerCase();
                    double salary = 0;

                    if (des.equals("programmer")) salary = 20000;
                    else if (des.equals("manager")) salary = 25000;
                    else if (des.equals("tester")) salary = 15000;
                    else {
                        System.out.println("Invalid designation");
                        break;
                    }

                    dao.addEmployee(new Employee(name, age, des, salary));
                    System.out.println("Employee added successfully!");
                    break;

                case 2:
                    List<Employee> employees = dao.getLast10Employees();
                    System.out.println("\nEmployee Details");
                    for (Employee e : employees) {
                        System.out.println(e.getName() + " | " + e.getAge() + " | " +
                                e.getDesignation() + " | " + e.getSalary());
                    }
                    break;

                case 3:
                    System.out.print("Enter employee name: ");
                    String n = sc.nextLine();

                    System.out.print("Enter raise percentage (1-10): ");
                    int p = sc.nextInt();
                    sc.nextLine();

                    if (p < 1 || p > 10) {
                        System.out.println("Invalid percentage");
                        break;
                    }

                    boolean ok = dao.raiseSalary(n, p);
                    if (ok) System.out.println("Salary updated");
                    else System.out.println("Employee not found");
                    break;

                case 4:
                    System.out.println("Thank you for using my application");
                    return;

                default:
                    System.out.println("Invalid choice");
            }
        }
    }
}