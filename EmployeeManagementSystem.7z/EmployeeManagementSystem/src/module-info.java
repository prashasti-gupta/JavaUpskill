/**
 * 
 */
/**
 * 
 */
module EmployeeManagementSystem {
	requires java.sql;
	requires mysql.connector.j;
}